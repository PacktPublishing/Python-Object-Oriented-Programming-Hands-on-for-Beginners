# https://www.globaletraining.com/

# Class Definition


class Car:
    # Class Attributes/Variables

    # Object Attributes/Variables

    # Methods
    pass