# https://www.globaletraining.com/
# Class Constructor/Initializer (__init__ & self)


class Car:
    # Class Attributes/Variables

    # Class Constructor/Initializer (Method with a special name)
    def __init__(self):
        # Object Attributes/Variables
        self.make = "Ford"
        self.model = "Mustang"
        self.year = 2010
        self.color = "Blue"
        self.moon_roof = True


    # Methods
    pass
