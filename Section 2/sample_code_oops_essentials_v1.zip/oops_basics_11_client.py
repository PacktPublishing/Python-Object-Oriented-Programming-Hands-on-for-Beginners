# https://www.globaletraining.com/
# import

from Module14_OOPs.aa_oops_essentials.oops_basics_10 import My_Calc

calc1 = My_Calc(100, 50)
total1 = calc1.total()
diff1 = calc1.diff()
print("Total1 : ", total1)
print("Diff1 : ", diff1)

print("-------------")
calc2 = My_Calc(50, 25)
total2 = calc2.total()
diff2 = calc2.diff()
print("Total2 : ", total2)
print("Diff2 : ", diff2)
