# https://www.globaletraining.com/
# Understanding Polymorphism

# Integers
number1 = 10
number2 = 20
print(number1 * number2)

# Strings
string1 = "Python"
string2 = "Programming"
print(string1 + string2)

# Lists
list1 = ["snake", "monkey"]
list2 = ["dog", "cat"]
print(list1 + list2)
